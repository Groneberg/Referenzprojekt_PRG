/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.dao;

import com.ibb.sg.model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Stefan Groneberg
 */
public class UserDAO {
    
    private Connection connection;
    private PreparedStatement createStatement;
    private PreparedStatement readUserIDStatment;
    

    public UserDAO() {
    }

    /**
     * Konstruktor 
     * initialisieren der Verbindung zur Datenbank
     * @param connection 
     */
    public UserDAO(Connection connection) {
        this.connection = connection;
    }
    
    /**
     * Erstellen eines neuen Datensatzes 
     * @param user
     * @return boolean 
     * Rückgabe von true, bei erfolgreichem Hinzufügen eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean create(User user) { // WIP 
    if (this.createStatement == null) {
            try {
                String sql = "INSERT INTO `user`(`U_EMail`, `U_PW`) VALUES (?,?)";
                this.createStatement = connection.prepareStatement(sql);
                this.createStatement.setString(1, user.geteMail());
                this.createStatement.setString(2, user.getPw());
                return this.createStatement.executeUpdate() == 1;
            } catch (SQLException e) {
                e.getMessage();
            }
        }
        return false;
    }
    
    /**
     * Auslesen der, zum Benutzer, gehörenden ID
     * @param user
     * @return int
     */
    public int readUserID(User user) {
        int id = 0;
        try {
            String sql = "SELECT U_ID FROM `user` WHERE U_EMail = ? AND U_PW = ?;";
            this.readUserIDStatment = connection.prepareStatement(sql);
            this.readUserIDStatment.setString(1, user.geteMail());
            this.readUserIDStatment.setString(2, user.getPw());
            ResultSet resultSet = this.readUserIDStatment.executeQuery();
            resultSet.first();
            id = resultSet.getInt("U_ID");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return id;
    }
}
