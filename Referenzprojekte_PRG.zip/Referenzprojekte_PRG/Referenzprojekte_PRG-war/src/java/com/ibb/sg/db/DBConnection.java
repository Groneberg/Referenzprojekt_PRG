package com.ibb.sg.db;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.sql.DataSource;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Stefan Groneberg
 */
@Named
@ApplicationScoped
public class DBConnection implements AutoCloseable, Serializable{

    private Connection connection; 

    /**
     * Konstruktor 
     * Erstellen einer Verbindung zur Datenquelle "jdbc/organizer"
     */
    public DBConnection() {
        try {
            Context ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup("jdbc/organizer");
            this.connection = ds.getConnection();
            System.out.println("connction:" + connection != null);
        } catch (SQLException | NamingException ex) {
            System.out.println(ex.getMessage());
            System.out.println(ex.toString());
        }
    }

    /**
     * Rückgabe der Datenbankverbindung
     * @return Connection
     */
    public Connection getConnection() {
        return connection;
    }
    
    @Override
    /**
     * Schließen der Datenbankverbindung
     */
    public void close() {
        System.out.println("DB closed");
        try {
            this.connection.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
