package com.ibb.sg.servlet;

import com.ibb.sg.ctrl.WebCtrl;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Stefan Groneberg
 */
@WebServlet(urlPatterns = "/appointmentToDBServlet")
public class AppointmentToDBServlet extends HttpServlet{
    @Inject
    private WebCtrl webCtrl;
    
    @Override
    public void doGet(HttpServletRequest request,HttpServletResponse response){

    }
    
    @Override
    /**
     * Überschriebene doPost Methode
     * Übergabe der Termine an die Datenbank, zum Erstellen neuer Datensätze
     */
    public void doPost(HttpServletRequest request,HttpServletResponse response){
        if (this.webCtrl.getAppointments().getList().size() > 0) { // WIP
            for (int i = 0; i < this.webCtrl.getAppointments().getList().size(); i++) {
                this.webCtrl.getdBCtrl().getAppointmentDAO().create(this.webCtrl.getAppointments().getList().get(i),
                this.webCtrl.getUserID());
            }
        }
    }
}
