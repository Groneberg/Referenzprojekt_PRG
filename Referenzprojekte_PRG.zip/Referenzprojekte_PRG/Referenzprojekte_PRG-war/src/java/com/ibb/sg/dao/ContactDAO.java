/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.dao;

import com.ibb.sg.model.Contact;
import com.ibb.sg.model.ContactList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Stefan Groneberg
 */
public class ContactDAO {

    private Connection connection;
    private PreparedStatement createStatement;
    private PreparedStatement readAllStatement;
    private PreparedStatement updateStatement;
    private PreparedStatement deleteStatement;

    public ContactDAO() {
    }

    /**
     * Konstruktor 
     * initialisieren der Verbindung zur Datenbank
     * @param connection 
     */
    public ContactDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Erstellen eines neuen Datensatzes 
     * @param contact
     * @param c_id
     * @param u_id
     * @return boolean 
     * Rückgabe von true, bei erfolgreichem Hinzufügen eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean create(Contact contact, int c_id, int u_id) {
        try {
            if (this.createStatement == null) {
                String sql = "CALL  p_create_contact (?,?,?,?,?,?,?,?,?,?,?)";
                this.createStatement = this.connection.prepareStatement(sql);
            }
            this.createStatement.setInt(1, c_id);// WIP
            this.createStatement.setInt(2, u_id);// WIP
            this.createStatement.setString(3, contact.getFirstName());
            this.createStatement.setString(4, contact.getLastName());
            this.createStatement.setString(5, contact.getTitle());
            this.createStatement.setString(6, contact.getLabel());
            this.createStatement.setString(7, contact.geteMail());
            this.createStatement.setString(8, contact.getPhone());
            this.createStatement.setString(9, contact.getAddress());
            this.createStatement.setString(10, contact.getLocation());
            this.createStatement.setString(11, contact.getZip());

            return this.createStatement.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    /**
     * Aktualisieren eines Datensatzes 
     * @param contact
     * @return boolean
     * Rückgabe von true, bei erfolgreichem Aktualisieren eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean update(Contact contact) {
        try {
            if (this.updateStatement == null) {
                String sql = "UPDATE `contact` SET `C_FName`= ?,`C_LName`= ?,`C_Title`= ?,`C_Label`= ?,`C_EMail`= ?,`C_Phone`= ?,`C_Address`= ?,`C_Location`= ?,`C_Zip`= ? WHERE `C_ID`= ?";
                this.updateStatement = this.connection.prepareStatement(sql);
            }
            this.updateStatement.setString(1, contact.getFirstName());
            this.updateStatement.setString(2, contact.getLastName());
            this.updateStatement.setString(3, contact.getTitle());
            this.updateStatement.setString(4, contact.getLabel());
            this.updateStatement.setString(5, contact.geteMail());
            this.updateStatement.setString(6, contact.getPhone());
            this.updateStatement.setString(7, contact.getAddress());
            this.updateStatement.setString(8, contact.getLocation());
            this.updateStatement.setString(9, contact.getZip());
            this.updateStatement.setString(10, contact.getId());
                    
            return this.updateStatement.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    /**
     * Löschen eines Datensatzes 
     * @param contact
     * @return boolean
     * Rückgabe von true, bei erfolgreichem Löschen eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean delete(Contact contact) {
        try {
            if (this.deleteStatement == null) {
                String sql = "DELETE FROM `contact` WHERE `C_ID` = ?";
                this.deleteStatement = this.connection.prepareStatement(sql);
            }
            this.deleteStatement.setInt(1, Integer.parseInt(contact.getId()));
            return this.deleteStatement.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Auslesen aller, zum Benutzer, gehörenden Kontakte
     * @param uID
     * @return ContactList
     */
    public ContactList readAllContacts(int uID) {
        ContactList contacts = new ContactList();
        try {
            if (readAllStatement == null) {
                String sql = "SELECT * FROM `contact` WHERE U_ID = ?"; // WIP
                readAllStatement = connection.prepareStatement(sql);
            }
            readAllStatement.setInt(1, uID);

            ResultSet resultSet = readAllStatement.executeQuery();
            while (resultSet.next()) {
                contacts.getList().add(new Contact(
                        "" + resultSet.getInt("C_ID"),
                        resultSet.getString("C_FName"),
                        resultSet.getString("C_LName"),
                        resultSet.getString("C_Phone"),
                        resultSet.getString("C_EMail"),
                        resultSet.getString("C_Address"),
                        resultSet.getString("C_Location"),
                        resultSet.getString("C_Zip"),
                        resultSet.getString("C_Label"),
                        resultSet.getString("C_Title"))
                );
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return contacts;
    }
    
    /**
     * Lesen der letzten ID 
     * @return int
     */
    public int readMaxID() {
        String temp = null;
        String sql = "SELECT MAX(C_ID) FROM `contact`;";
        try {
            ResultSet rs = connection.createStatement().executeQuery(sql);
            rs.first();
            temp = rs.getString(1);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        if (temp == null) {
            temp = "0";
        }
        return Integer.parseInt(temp);
    }
}
