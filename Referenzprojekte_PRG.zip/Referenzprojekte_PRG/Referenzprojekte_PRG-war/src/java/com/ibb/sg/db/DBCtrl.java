/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.db;

import com.ibb.sg.dao.AppointmentDAO;
import com.ibb.sg.dao.ContactDAO;
import com.ibb.sg.dao.UserDAO;
import java.io.Serializable;
import java.sql.Connection;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Stefan Groneberg
 */
@Named
@SessionScoped
public class DBCtrl implements Serializable {

    private Connection connection;
    
    private ContactDAO contactDAO;
    private AppointmentDAO appointmentDAO;
    private UserDAO userDAO;

    /**
     * Konstruktor
     * Initialisieren der Attribute des DBCtrl 
     * @param connection 
     */
    public DBCtrl(Connection connection ) {
        this.connection = connection;
        this.contactDAO = new ContactDAO(this.connection);
        this.appointmentDAO = new AppointmentDAO(this.connection);
        this.userDAO = new UserDAO(this.connection);
    }

    /**
     * Rückgabe des Data Access Object für Kontakte
     * @return ContactDAO
     */
    public ContactDAO getContactDAO() {
        return contactDAO;
    }

    /**
     * Rückgabe des Data Access Object für Termine
     * @return AppointmentDAO
     */
    public AppointmentDAO getAppointmentDAO() {
        return appointmentDAO;
    }

    /**
     * Rückgabe des Data Access Object für Benutzer
     * @return UserDAO
     */
    public UserDAO getUserDAO() {
        return userDAO;
    }
    
    
}
