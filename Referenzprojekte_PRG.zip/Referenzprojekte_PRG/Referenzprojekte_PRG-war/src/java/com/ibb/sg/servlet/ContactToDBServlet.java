package com.ibb.sg.servlet;

import com.ibb.sg.ctrl.WebCtrl;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Stefan Groneberg
 */
@WebServlet(urlPatterns = "/contactToDBServlet")
public class ContactToDBServlet extends HttpServlet {

    @Inject
    private WebCtrl webCtrl;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    /**
     * Überschriebene doPost Methode
     * Übergabe der Termine an die Datenbank, zum Erstellen neuer Datensätze
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        if (this.webCtrl.getContacts().getList().get(0).getId() != null) { // WIP
            for (int i = 0; i < this.webCtrl.getContacts().getList().size(); i++) {
                this.webCtrl.getdBCtrl().getContactDAO().create(
                        this.webCtrl.getContacts().getList().get(i),
                        Integer.parseInt(this.webCtrl.getContacts().getList().get(i).getId()),
                        this.webCtrl.getUserID());

            }
        }
    }
}
