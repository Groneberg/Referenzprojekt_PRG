package com.ibb.sg.ctrl;

import com.ibb.sg.db.DBConnection;
import com.ibb.sg.db.DBCtrl;
import com.ibb.sg.model.Appointment;
import com.ibb.sg.model.AppointmentList;
import com.ibb.sg.model.Contact;
import com.ibb.sg.model.ContactList;
import com.ibb.sg.model.User;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Stefan Groneberg
 */
@Named
@SessionScoped
public class WebCtrl implements Serializable {
    
    @Inject
    private DBConnection dBConnection; 
    private int lastAppointmentID;
    private ContactList contacts;
    private Contact contact;
    private User user;
    private int userID;
    private int delID;
    private boolean loggedIn;
    private HashSet delHashSet;
    private HashSet upDateHashSet;
    private Appointment appointment;
    private AppointmentList appointments;
    private DBCtrl dBCtrl;

    public WebCtrl() {
    }
    
    
    @PostConstruct
    /**
     * Initialisieren der Attribute des WebCtrl 
     * 
     */
    public void init() {
        this.contact = new Contact();
        this.contacts = new ContactList();
        this.user = new User();
        this.delHashSet = new HashSet();
        this.upDateHashSet = new HashSet();
        this.appointment = new Appointment();
        this.appointments = new AppointmentList();
        this.contacts.getList().add(new Contact());
        this.dBCtrl = new DBCtrl(this.dBConnection.getConnection());
    }

    /**
     * Rückgabe der ID des Letzten Termins
     * @return int 
     */
    public int getLastAppointmentID() {
        return lastAppointmentID;
    }

    /**
     * Setzen des Attributs, welche die ID des letzten Termins speichert
     * @param lastAppointmentID 
     */
    public void setLastAppointmentID(int lastAppointmentID) {
        this.lastAppointmentID = lastAppointmentID;
    }

    /**
     * Rückgabe der Liste von Kontakten
     * @return ContactList 
     */
    public ContactList getContacts() {
        return contacts;
    }

    /**
     * Setzen der List von Kontakten
     * @param contacts 
     */
    public void setContacts(ContactList contacts) {
        this.contacts = contacts;
    }

    /**
     * Rückgabe des Attributs, welches den letzten erstellten oder bearbeiteten 
     * Kontakt speichert
     * @return Contact 
     */
    public Contact getContact() {
        return contact;
    }

    /**
     * Setzen  des Attributs, welches den letzten erstellten oder bearbeiteten 
     * Kontakt speichert
     * @param contact 
     */
    public void setContact(Contact contact) {
        this.contact = contact;
    }

    /**
     * Rückgabe des Attributs, welches den Benutzer der Sitzung 
     * speichert 
     * @return User 
     */
    public User getUser() {
        return user;
    }

    /**
     * Setzen des Attributs, welches den Benutzer der Sitzung 
     * speichert 
     * @param user 
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Rückgabe des Attributs, welches die ID des Benutzer  
     * speichert 
     * @return int 
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Setzen des Attributs, welches die ID des Benutzer  
     * speichert 
     * @param userID 
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Rückgabe des Attributs, welches die ID des zu löschendesn KOntaktes oder 
     * Termins speichert 
     * @return int 
     */
    public int getDelID() {
        return delID;
    }

    /**
     * Setzen des Attributs, welches die ID des zu löschendesn KOntaktes oder 
     * Termins speichert 
     * @param delID 
     */
    public void setDelID(int delID) {
        this.delID = delID;
    }

    /**
     * Rücggabes des Attributs, welches speichert ob ein Benutzer angemeldet ist 
     * @return boolean 
     */
    public boolean isLoggedIn() {
        return loggedIn;
    }

    /**
     * Setzen des Attributs, welches speichert ob ein Benutzer angemeldet ist 
     * @param loggedIn 
     */
    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }

    /**
     * Rückgabe einer Liste von IDs, der zu löschenden Kontakte 
     * @return HashSet 
     * ist überflüssig geworden
     */
    public HashSet getDelHashSet() {
        return delHashSet;
    }

    /**
     * Rückgabe des Attributs, welches den letzten erstellten oder bearbeiteten 
     * Termin speichert
     * @return Appointment 
     */
    public Appointment getAppointment() {
        return appointment;
    }

    /**
     * Setzen des Attributs, welches den letzten erstellten oder bearbeiteten 
     * Termin speichert
     * @param appointment 
     */
    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    /**
     * Rückgabe der Liste von Terminen
     * @return AppointmentList 
     */
    public AppointmentList getAppointments() {
        return appointments;
    }

    /**
     * Setzen der Liste von Terminen
     * @param appointments 
     */
    public void setAppointments(AppointmentList appointments) {
        this.appointments = appointments;
    }

    /**
     * Rückgabes des Attribut für Datenbank-Controller 
     * @return DBCtrl 
     */
    public DBCtrl getdBCtrl() {
        return dBCtrl;
    }

    /**
     * Zeigt Daten eines Hashset
     * @param set 
     */
    public void showHashSetData(HashSet set) {
        System.out.println("=== Iterate over a HashSet using iterator() ===");
        Iterator<Integer> setIterator = set.iterator();
        while (setIterator.hasNext()) {
            Object temp = (Object) setIterator.next();
            System.out.println(temp);
        }
    }

    /**
     * Fügt der Liste ContactList contacts einen neuen Kontakt hinzu
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String addKontakt() {
        this.contact.setId("" + (this.dBCtrl.getContactDAO().readMaxID() + 1));
        this.contacts.getList().add(new Contact(
                this.contact.getId(),
                this.contact.getFirstName(),
                this.contact.getLastName(),
                this.contact.getPhone(),
                this.contact.geteMail(),
                this.contact.getAddress(),
                this.contact.getLocation(),
                this.contact.getZip(),
                this.contact.getLabel(),
                this.contact.getTitle())
        );
        if (contacts.getList().get(0).getId() == null) {
            contacts.getList().remove(0);
        }
        return "toContact";
    }

    /**
     * Aktualisiert einen Kontakt in der Liste ContactList contacts
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String updateKontakt() {
        this.dBCtrl.getContactDAO().update(this.contact);
        for (int i = 0; i < this.contacts.getList().size(); i++) {
            if (String.valueOf(this.contact.getId()).equals(this.contacts.getList().get(i).getId())) {
                this.contacts.getList().get(i).setFirstName(this.contact.getFirstName());
                this.contacts.getList().get(i).setLastName(this.contact.getLastName());
                this.contacts.getList().get(i).setPhone(this.contact.getPhone());
                this.contacts.getList().get(i).seteMail(this.contact.geteMail());
                this.contacts.getList().get(i).setAddress(this.contact.getAddress());
                this.contacts.getList().get(i).setLocation(this.contact.getLocation());
                this.contacts.getList().get(i).setZip(this.contact.getZip());
                this.contacts.getList().get(i).setLabel(this.contact.getLabel());
                this.contacts.getList().get(i).setTitle(this.contact.getTitle());
            return "toContact";
            }
        }
        return "toContact";
    }

    /**
     * Löscht Kontakt aus der Liste ContactList contacts
     */
    public void delKontakt() {
        for (int i = 0; i < this.contacts.getList().size(); i++) {
            System.out.println("id" + contacts.getList().get(i).getId());
            System.out.println(this.delID + " " + this.contacts.getList().get(i).getId());
            if (this.delID == Integer.parseInt(this.contacts.getList().get(i).getId())) {
                if (this.dBCtrl.getContactDAO().delete(this.contacts.getList().get(i))) {
                    this.contacts.getList().remove(i);
                }
            }
        }
    }
    
    /**
     * Fügt der Liste AppointmentList appointments einen neuen Termin 
     * hinzu
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String addAppointment() {
        this.lastAppointmentID++; // WIP
        this.appointment.setId("" + this.lastAppointmentID);
        this.appointments.getList().add(new Appointment(
                this.appointment.getId(),
                this.appointment.getEvent(),
                this.appointment.getNote(),
                this.appointment.getBeginTimestamp(),
                this.appointment.getEndTimestamp(),
                this.appointment.getDuration())
        );
        return "toCalendar";
    }
    
    /**
     * Aktualisiert einen Termin in der Liste AppointmentList appointments
     */
    public void updateAppointment() {
        this.dBCtrl.getAppointmentDAO().update(this.appointment);
        for (int i = 0; i < this.appointments.getList().size(); i++) {
            if (String.valueOf(this.appointment.getId()).equals(this.appointments.getList().get(i).getId())) {
                this.appointments.getList().get(i).setEvent(this.appointment.getEvent());
                this.appointments.getList().get(i).setBeginTimestamp(this.appointment.getBeginTimestamp());
                this.appointments.getList().get(i).setEndTimestamp(this.appointment.getEndTimestamp());
                this.appointments.getList().get(i).setDuration(this.appointment.getDuration());
                this.appointments.getList().get(i).setNote(this.appointment.getNote());
            }
        }
    }
    
    /**
     * Löschen eines Termin aus der Liste AppointmentList appointments
     */
    public void delAppointment() {
        this.dBCtrl.getAppointmentDAO().delete(this.appointment);
        for (int i = 0; i < this.appointments.getList().size(); i++) {
            if (String.valueOf(this.appointment.getId()).equals(this.appointments.getList().get(i).getId())) {
                this.appointments.getList().remove(i);
            }
        }
    }

    /**
     * Übergibt neuen Benutzer an Datenbank-Controller,
     * um diesen in der Datenbank abzuspeichern
     */
    public void addUserToDB() {
        this.dBCtrl.getUserDAO().create(this.user);
        this.userID = this.dBCtrl.getUserDAO().readUserID(this.user);
        System.out.println(this.userID);
    }
    
    /**
     * Anmelden des Benutzers 
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String login() {
        this.userID =  this.dBCtrl.getUserDAO().readUserID(user);
        if (this.userID != 0) {
            this.loggedIn = true;
            setContacts(this.dBCtrl.getContactDAO().readAllContacts(this.userID));
            setAppointments(this.dBCtrl.getAppointmentDAO().readAllContacts(this.userID));
        } else {
            this.loggedIn = false;
        }
        return "toStart";
    }
    
    /**
     * Abmelden des Benutzers
     * @param request
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate();
        this.loggedIn = false;
        return "toStart";
    }
    
    /**
     * Wechsel der Seite, zur Kontaktseite
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String toContact() {
        return "toContact";
    }

    /**
     * Wechsel der Seite, zur Startseite
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String toStart() {
        return "toStart";
    }

    /**
     * wechsel der Seite, zur Kalenderseite
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String toCalendar() {
        return "toCalendar";
    }

    /**
     * Wechsel der Seite, zur Loginseite
     * @return String 
     * Rückgabewert notwendig für Seitenaktualisierung
     */
    public String toLogin() {
        return "toLogin";
    }
    
}
