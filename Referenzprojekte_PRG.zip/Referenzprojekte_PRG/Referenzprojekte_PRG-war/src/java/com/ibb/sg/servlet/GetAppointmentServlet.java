/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.servlet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibb.sg.ctrl.WebCtrl;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Stefan Groneberg
 */
@WebServlet(urlPatterns = "/getAppointmentServlet")
public class GetAppointmentServlet extends HttpServlet{
    @Inject
    private WebCtrl webCtrl;
    private String jsonObject;
    
    @Override
    public void doGet(HttpServletRequest request,HttpServletResponse response){

    }
    @Override
    /**
     * Überschriebene doPost Methode
     * Übergabe der Termine vom WebCtrl an die Webseite
     */
    public void doPost(HttpServletRequest request,HttpServletResponse response){
        response.setContentType("application/json");
        try {
            if (this.webCtrl.getAppointments().getList().size() > 0) {
                
            PrintWriter out = response.getWriter();
    //        https://github.com/google.gson
            GsonBuilder gsonBuilder = new GsonBuilder();

            Gson gson = gsonBuilder.create();

            this.jsonObject = gson.toJson(this.webCtrl.getAppointments().getList());
//            log(jsonObject);
            
            out.print(jsonObject);
            out.flush();
            }
        } catch (IOException ex) {
            Logger.getLogger(GetAppointmentServlet.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    
}
