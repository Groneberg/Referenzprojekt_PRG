/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.dao;

import com.ibb.sg.model.Appointment;
import com.ibb.sg.model.AppointmentList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Stefan Groneberg
 */
public class AppointmentDAO {

    private Connection connection;
    private PreparedStatement createStatement;
    private PreparedStatement readAllStatement;
    private PreparedStatement updateStatement;
    private PreparedStatement deleteStatement;
    
    public AppointmentDAO() {
    }

    /**
     * Konstruktor 
     * initialisieren der Verbindung zur Datenbank
     * @param connection 
     */
    public AppointmentDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Erstellen eines neuen Datensatzes 
     * @param appointment
     * @param u_id
     * @return boolean 
     * Rückgabe von true, bei erfolgreichem Hinzufügen eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean create(Appointment appointment, int u_id) { // WIP 
        try {
            if (this.createStatement == null) {
                String sql = "CALL p_create_appointment (?,?,?,?,?,?)";
                this.createStatement = this.connection.prepareStatement(sql);
            }
            
            this.createStatement.setInt(1, u_id);
            this.createStatement.setString(2, appointment.getEvent());
            this.createStatement.setString(3, appointment.getNote());
            this.createStatement.setString(4, appointment.getBeginTimestamp());
            this.createStatement.setString(5, appointment.getEndTimestamp());
            this.createStatement.setString(6, "" + appointment.getDuration());
            return this.createStatement.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    /**
     * Aktualisieren eines Datensatzes 
     * @param appointment
     * @return boolean
     * Rückgabe von true, bei erfolgreichem Aktualisieren eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean update(Appointment appointment) {
        try {
            if (this.updateStatement == null) {
                String sql = "UPDATE `appointment` SET `A_Event`= ?,`A_Note`= ?,`A_Beginning`= ?,`A_Ending`= ?,`A_Duration`= ? WHERE `A_ID` = ?;";
                this.updateStatement = this.connection.prepareStatement(sql);
            }
            
            this.updateStatement.setString(1, appointment.getEvent());
            this.updateStatement.setString(2, appointment.getNote());
            this.updateStatement.setString(3, appointment.getBeginTimestamp());
            this.updateStatement.setString(4, appointment.getEndTimestamp());
            this.updateStatement.setString(5, "" + appointment.getDuration());
            this.updateStatement.setInt(6, Integer.parseInt(appointment.getId()));
            return this.updateStatement.executeUpdate() == 1;
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    /**
     * Löschen eines Datensatzes 
     * @param appointment
     * @return boolean
     * Rückgabe von true, bei erfolgreichem Löschen eines Datensatzes
     * Rückgabe von false, bei Misserfolg
     */
    public boolean delete(Appointment appointment) {
        try {
            if (this.deleteStatement == null) {
                String sql = "DELETE FROM `appointment` WHERE A_ID = ?";
                this.deleteStatement = this.connection.prepareStatement(sql);
            }
            this.deleteStatement.setInt(1, Integer.parseInt(appointment.getId()));

            return this.deleteStatement.executeUpdate() == 1;
        } catch (NumberFormatException | SQLException e) {
//            Logger.getLogger(AppointmentDAO.class.getName()).log(Level.SEVERE, null, e);
            System.out.println(e.getMessage());
        }
        return false;
    }
    
    /**
     * Auslesen aller, zum Benutzer, gehörende Termine
     * @param uID
     * @return AppointmentList
     */
    public AppointmentList readAllContacts(int uID) {
        AppointmentList appointments = new AppointmentList();
        try {
            if (readAllStatement == null) {
                String sql = "SELECT * FROM `appointment` WHERE U_ID = ?"; // WIP
                readAllStatement = connection.prepareStatement(sql);
            }
            readAllStatement.setInt(1, uID);

            ResultSet resultSet = readAllStatement.executeQuery();
            while (resultSet.next()) {
                appointments.getList().add(new Appointment(
                        "" + resultSet.getInt("A_ID"),
                        resultSet.getString("A_Event"),
                        resultSet.getString("A_Note"),
                        resultSet.getString("A_Beginning"),
                        resultSet.getString("A_Ending"),
                        Integer.parseInt(resultSet.getString("A_Duration"))
                ));
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return appointments;
    }
}
