$().ready(function () {   
    // Setzen von sessionStorage
    if (sessionStorage.login === undefined) {
        sessionStorage.setItem("login", "false");
    }
    
    sessionStorage.login = $("#loginIdentifier").text();
    
    // Verstecken des Login-Formulars
    if (sessionStorage.login === "true"){
        $(".loginWrapper").hide();
        $("aside.indexNav").css({
            "display": "inline-block"
        });
    } 
    
    // Wechsel zu Registrierungsformular 
    $("#notRegisteredButton").click(function () {
        $(".registerWrapper").css({
            "display": "flex"
        });
        $(".loginWrapper").css({
            "display": "none"
        }); 
    });
    
    // Wechsel zu Login-Formular 
    $("#toLoginButton").click(function () {
        $(".registerWrapper").css({
            "display": "none"
        }); 
        $(".loginWrapper").css({
            "display": "flex"
        }); 
    });
});
