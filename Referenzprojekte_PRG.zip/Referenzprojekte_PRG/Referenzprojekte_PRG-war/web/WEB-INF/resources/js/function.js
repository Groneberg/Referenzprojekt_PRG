// Setzen Event zum Abmelden des Benutzers
$().ready(function () {   
    $("input[id*='logoutButton']").click(function () {
        sessionStorage.login = "false";
    });   
});
