var lastID;
var contacts;

// Schreibt ID des jeweiligen Kontaktes in das HTML Dokument
function setInputUpdateValue() {
    $(".inputUpdateValue").each(function (i, element) {
        var temp = $(element).closest(".contactRow").attr("id");
        temp = temp.substring(5, (temp.length));
        element.setAttribute("value", temp);
    });
}

// Schreibt die Daten des zu bearbeitenden Kontaktes in das Formular zum Berabeiten
function setUpdateContact(id) {
    var $contact = $("#updateInput input");
    for (var i = 0, max = contacts.length; i < max; i++) {
        if (contacts[i].id === id) {
            $contact[0].value = contacts[i].firstName;
            $contact[1].value = contacts[i].lastName;
            $contact[2].value = contacts[i].title;
            $contact[3].value = contacts[i].label;
            $contact[4].value = contacts[i].phone;
            $contact[5].value = contacts[i].eMail;
            $contact[6].value = contacts[i].address;
            $contact[7].value = contacts[i].location;
            $contact[8].value = contacts[i].zip;
        }
    }
}

// Schreiben des Ausgewählten Kontaktes in das HTML Dokument
function setDisplayContact(id) {
    var $contact = $(".contactDisplay p");
    for (var i = 0, max = contacts.length; i < max; i++) {
        if (contacts[i].id === id) {
            $contact[0].innerHTML = contacts[i].firstName;
            $contact[1].innerHTML = contacts[i].lastName;
            $contact[2].innerHTML = contacts[i].title;
            $contact[3].innerHTML = contacts[i].label;
            $contact[4].innerHTML = contacts[i].phone;
            $contact[5].innerHTML = contacts[i].eMail;
            $contact[6].innerHTML = contacts[i].address;
            $contact[7].innerHTML = contacts[i].location;
            $contact[8].innerHTML = contacts[i].zip;
        }
    }
}

// Setzt sesssessionStorage.contactCheck = true 
function setContactCheck() { // WIP
    if (sessionStorage.contactCheck === undefined) {
        sessionStorage.setItem("contactCheck", "true");
    }
    sessionStorage.contactCheck = "true";
}

$().ready(function () {   
    if (sessionStorage.contactCheck === "true") {
        // AJAX Request zum Übertragen der Kontakte in die Datenbank
        $.post("../../contactToDBServlet"); 
        sessionStorage.contactCheck = "false";
    }

    // laden der Kontakte vom Server
    $.post("../../getContactServlet", function (responseText) {
        contacts = responseText;
    });

    // Event zur Anzeige des Formulares zum Hinzufügen eines Kontaktes
    $("#newButton").click(function () {
        $(".contactInputTextWrapper input").val("");
        $(".contactAddFormWrapper").css({"display": "block"});
    });

    // Event zur Anzeige des Formulares zum Bearbeiten eines Kontaktes
    $(".updateButton").click(function () {
        var id = $(this).closest(".contactRow").attr("data-delID");
        setUpdateContact(id);
        $("input[id*='inputUpdateValue']").val(id);
        $("input[id*='editContactInputID']").val(id);
        $(".contactUpDateFormWrapper").css({"display": "block"});
    });
    
    $(".contactDisplay").ready(function () {
        // Event zum Anzeigen des Ausgewählten Kontaktes
        $(".tdCell").click(function () {
            var id = $(this).closest(".contactRow").attr("data-delID");
            setDisplayContact(id);
            $(".contactDisplay").css({
                "display": "flex"
            });
        });
        // Event zum Verstecken der Anzeige 
        $(".contactDisplay").click(function () {
            $(this).css({
                "display": "none"
            });
        });
    });

    $(".contactAddFormWrapper").ready(function () {
        // Event zum Verstecken des Formulars zum Kontakt hinzufügen
        $("#backButtonAdd").click(function () {
            $(".contactAddFormWrapper").css({"display": "none"});
        });
    });

    // Event zum Verstecken des Formulars zum Kontakt bearbeiten
    $(".contactUpDateFormWrapper").ready(function () {
        $("#backButtonUpdate").click(function () {
            $(".contactUpDateFormWrapper").css({"display": "none"});
        });
    });    
    
    // Bestätigen eines neuen Kontaktes vor dem Submit
    $("#addContactFormID").submit(function () { // WIP
        var $contact = $("#addInput input");
        var check = true;
        if (contacts !== undefined) {
            for (var i = 0; i < contacts.length; i++) {
                check = $contact[5].value !== contacts[i].eMail;
                if (check === false) {
                    alert("Dieser Kontakt existiert bereits! ");
                    return false;
                }
            }
        }
        if (check) {
            setContactCheck();
        }
        return check;
    });
});

