const Minute = 60 * 1000;
const Hour = Minute * 60;
const Day = Hour * 24;
const Week = Day * 7;
const Month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const  monthString = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September',
    'Oktober', 'November', 'Dezember'];
var dayBridge = [6, 0, 1, 2, 3, 4, 5];
const BaseTimestamp = getBaseTimestamp();
const FirstOfCurrentMonth = getFirstOfCurrentMonth();
var transitonTimestamp = BaseTimestamp;
var transitonMonthTimestamp = getFirstOfCurrentMonth();
var appointments = [];
var appointmentCheck;
var appointmentTimestamp;
var appointmentID;
var updateOrDelete;

// Rückgabe einer Zahl < 10 mitführenden 0 für die Datumanzeige
function leadingZeros(number) {
    number = (number < 10 ? '0' : '') + number;
    return number;
}

// Rückgabe des Datums mit bestimmten Zeitstempel
function dateFromTimestamp(timestamp) {
    var date = new Date((parseInt(timestamp))),
            day = date.getDate(),
            dayNumber = date.getDay(),
            weekDay = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'],
            monthNumber = date.getMonth(),
            monthString = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September',
                'Oktober', 'November', 'Dezember'],
            text;
    text = weekDay[dayNumber] + ', der ' + leadingZeros(day) + '. ' + monthString[monthNumber] + '.';
    return text;
}

// Rückgabe eines Zeitstempels des aktuellen Tages um 0:00 Uhr
function getBaseTimestamp() {
    var d = new Date();
    var temp = leadingZeros(d.getDate()) + " " + Month[d.getMonth()] + " " + d.getFullYear() + " 00:00:00 GMT";
    return Date.parse(temp);
}

// Rückgabe eines Zeitstempels des ersten Tages des aktuellen Monats um 0:00 Uhr
function getFirstOfCurrentMonth() {
    var d = new Date(BaseTimestamp);
    var differenz = d.getDate() - 1;
    return BaseTimestamp - (differenz * Day);
}

// Rückgabe der Kalenderwochennummer
function getWeekNumber(timestamp) {
    var d = new Date(timestamp);
    d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
    var week1 = new Date(d.getFullYear(), 0, 4);
    return 1 + Math.round(((d.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

// Darstellen der Termine im Monatskalender
function displayInMonthCalender(firstOfMonthTimestamp) {
    var d = new Date(firstOfMonthTimestamp);
    var $dayDisplay = $(".dayDisplay");
    var firstCalenderElementTimestamp = firstOfMonthTimestamp - (dayBridge[d.getDay()] * Day);
    $("#idMonthDisplay").text(monthString[d.getMonth()] + " " + d.getFullYear());
    $(".appointmentDisplay").remove();

    for (var i = 0, x = 0, timestamp = firstCalenderElementTimestamp; i < 7; i++) {
        for (var j = 0, tempTimestamp = timestamp; j < 6; j++, x++) {
            var date = new Date(tempTimestamp);
            $dayDisplay.eq(x).find("h3").text(date.getDate());
            $dayDisplay.eq(x).attr("data-timestamp", tempTimestamp);
            // Filtern der Termine, welche zu dem Tag gehören und Schreiben der 
            // Termine in die Webseite
            if (appointments[0] !== undefined) {
                for (var k = 0, counter = 1; k < appointments.length; k++) {
                    var begin = new Date(parseInt(appointments[k].beginTimestamp));
                    if (
                            date.getDate() === begin.getDate() &&
                            date.getDay() === begin.getDay() &&
                            begin.getMonth() === date.getMonth()) {
                        displayAppointmentMonth(appointments[k], tempTimestamp, counter);
                        counter++;
                    }
                }
            }
            tempTimestamp = tempTimestamp + (7 * Day);
        }
        timestamp += Day;
    }
    setEventsMonthCalender($dayDisplay);
}

// Setzen von Events für Monatskalender
function setEventsMonthCalender($dayDisplay) {
    $dayDisplay.has(".appointment").each(function (i, element) {
        var x, y;
        $(element).hover(function () {
            rect = element.getBoundingClientRect();
            x = rect.left;
            y = rect.top;
            var div = $(element).find(".appointment").show();
            div.css({
                "display": "inline",
                "left": x + 1,
                "top": y + 1
            });
        }, function () {
            $(element).find(".appointment").hide();
        });
    });

    $(".appointment p").each(function (i, element) {
        // Event für die Anzeige des Termins auf der Webseite
        $(element).on("mousemove", function (event) {
            var id = $(element).attr("data-id");
            var temp = getAppointmentFromList(id);
            var begin = new Date(parseInt(temp.beginTimestamp));
            var end = new Date(parseInt(temp.endTimestamp));
            var y = event.clientY;
            $(".appointmentDetails").css({
                "display": "flex"
            });

            $("h2.appointmentDetailsEvent").text(temp.event);
            $("p.appointmentDetailsDuration").text("Dauer: " + temp.duration);
            $("p.appointmentDetailsTime").text(
                    "Beginn: " + leadingZeros(begin.getUTCHours()) + ":" +
                    leadingZeros(begin.getUTCMinutes()) + " Uhr" +
                    "  Ende: " + leadingZeros(end.getUTCHours()) + ":" +
                    leadingZeros(end.getUTCMinutes()) + " Uhr"
                    );
            $("p.appointmentDetailsNote").text(temp.note);
        });
        // Event zum verstecken des Termins
        $(element).on("mouseleave", function () {
            $(".appointmentDetails").css({
                "display": "none"
            });
        });
    });

    $(".dayDisplay").each(function (i, element) {
        // Event für die Anzeige des Formulars zum hinzufügen eines Termins
        $(element).click(function () {
            appointmentTimestamp = parseInt($(element).attr("data-timestamp"));
            $(".addAppointmentFormWrapper").show();
            $("#addAppointmentFormId .appointmentFormInputWrapper:first-of-type input").val("");
            $("textarea[id*=addNoteTextarea]").val("");
        });
    });

    $(".appointmentDisplay p").each(function (i, element) {
        // Event für die Anzeige des Formulars zum Bearbeiten eines Termins
        $(element).click(function () {
            appointmentTimestamp = $(element).closest(".dayDisplay").attr("data-timestamp");
            appointmentID = $(element).attr("data-id");
            setUpdateAppointment(appointmentID);
            $(".editAppointmentFormWrapper").show();
        });
    });
}

// Darstellen der Termine im Wochenkalender
function displayInWeekCalender(timestampInWeek) {
    var d = new Date(timestampInWeek);
    var $dayCaptureDate = $("h2.dayCaptureDate");
    var firstCalenderElementTimestamp = timestampInWeek - (dayBridge[d.getDay()] * Day);
    var monthArray = [];
    var monthText;
    // Schreiben der Kalenderwochennummer in die Webseite
    $("#weekNumberID").text("KW " + getWeekNumber(timestampInWeek));
    // Schreiben des Monats oder der Monate (wenn die woche in 2 Monaten liegt) in die Webseite
    for (var i = 0, timestamp = firstCalenderElementTimestamp; i < 7; i++) {
        var date = new Date(timestamp);
        if (monthArray.length < 2 && (monthArray.length === 0 || monthArray[0] !== monthString[date.getMonth()])) {
            monthArray.push(monthString[date.getMonth()]);
        }
        $dayCaptureDate.eq(i).text(date.getDate());
        $dayCaptureDate.eq(i).parent().attr("data-timestamp", timestamp);
        timestamp = timestamp + Day;
    }
    monthText = monthArray.toString();
    monthText = monthText.replace(",", " / ");

    $("#idMonthDisplay").text(monthText);
    // Filtern der Termine, welche zu der Woche gehören und Schreiben der 
    // Termine in die Webseite
    $(".appointmentDisplay").remove();
    if (appointments[0] !== undefined) {
        var $weekDay = $(".weekDay");
        for (var i = 0; i < $weekDay.length; i++) {
            for (var j = 0; j < appointments.length; j++) {
                var begin = new Date(parseInt(appointments[j].beginTimestamp));
                var dataTimeStamp = new Date(parseInt($weekDay[i].getAttribute("data-timestamp")));
                if (
                        begin.getDate() === dataTimeStamp.getDate() &&
                        begin.getDay() === dataTimeStamp.getDay() &&
                        begin.getMonth() === dataTimeStamp.getMonth()) {
                    displayAppointmentWeek(appointments[j], $weekDay[i].getAttribute("data-timestamp"));
                }
            }
        }
    }
    setEventsWeekCalender();
}

// Setzen von Events für Wochenkalender
function setEventsWeekCalender() {
    $(".weekDay").each(function (i, element) {
        $(element).click(function () {
            appointmentTimestamp = parseInt($(element).attr("data-timestamp"));
            $(".addAppointmentFormWrapper").show();
        });
    });
    // Event für die Anzeige des Formulars zum hinzufügen eines Termins
    $(".appointmentDisplay").click(function (event) {
        event.stopPropagation();
        appointmentID = $(this).attr("data-id");
        appointmentTimestamp = parseInt($(this).closest(".weekDay").attr("data-timestamp"));
        setUpdateAppointment(appointmentID);
        $(".editAppointmentFormWrapper").show();
    });
    
    $(".appointmentDisplay").each(function (i, element) {
        // Event für die Anzeige der jeweiligen Termindetails
        $(element).on("mousemove", function (event) {
            var id = $(element).attr("data-id");
            var temp = getAppointmentFromList(id);
            var begin = new Date(parseInt(temp.beginTimestamp));
            var end = new Date(parseInt(temp.endTimestamp));
            var y = event.clientY;
            $(".appointmentDetails").css({
                "display": "flex"
            });

            $("h2.appointmentDetailsEvent").text(temp.event);
            $("p.appointmentDetailsDuration").text("Dauer: " + temp.duration);
            $("p.appointmentDetailsTime").text(
                    "Beginn: " + leadingZeros(begin.getUTCHours()) + ":" +
                    leadingZeros(begin.getUTCMinutes()) + " Uhr" +
                    "  Ende: " + leadingZeros(end.getUTCHours()) + ":" +
                    leadingZeros(end.getUTCMinutes()) + " Uhr"
                    );
            $("p.appointmentDetailsNote").text(temp.note);
        });
        // Event zum verstecken der jeweiligen Termindetails
        $(element).on("mouseleave", function () {
            $(".appointmentDetails").css({
                "display": "none"
            });
        });
    });
}

// Darstellen der Termine im Tageskalender
function displayInDayCalender(timestampOfDay) {
    var d = new Date(timestampOfDay);
    var day = $("#idDateDisplay");
    day.text(dateFromTimestamp(timestampOfDay));
    day.attr("data-timestamp", timestampOfDay);

    $(".appointmentDisplay").remove();
    $("[data-hour]").attr("style", "");
    if (appointments[0] !== undefined) {
        for (var i = 0; i < appointments.length; i++) {
            var begin = new Date(parseInt(appointments[i].beginTimestamp));
            if (
                    begin.getDate() === d.getDate() &&
                    begin.getDay() === d.getDay() &&
                    begin.getMonth() === d.getMonth()) {
                displayAppointmentDay(appointments[i]);
            }
        }
    }
    setEventsDayCalender();
}

// Setzen von Events für Tageskalender
function setEventsDayCalender() {
    // Event für die Anzeige des Formulars zum Bearbeiten eines Termins
    $(".appointmentDisplay").click(function (event) {
        event.stopPropagation();
        appointmentID = $(this).attr("data-id");
        appointmentTimestamp = parseInt($(".calenderDayWrapper h2[data-timestamp]").attr("data-timestamp"));
        setUpdateAppointment(appointmentID);
        $(".editAppointmentFormWrapper").show();
    });
}

// Wechsel zu vorherigem Monat
function prevMonth() {
    var d = new Date(transitonMonthTimestamp);
    d.setMonth(d.getMonth() - 1);
    transitonMonthTimestamp = d.valueOf();
    displayInMonthCalender(transitonMonthTimestamp);
}

// Wechsel zu folgendem Monat
function nextMonth() {
    var d = new Date(transitonMonthTimestamp);
    d.setMonth(d.getMonth() + 1);
    transitonMonthTimestamp = d.valueOf();
    displayInMonthCalender(transitonMonthTimestamp);
}

// Wechsel zu vorheriger Woche
function prevWeek() {
    transitonTimestamp = transitonTimestamp - Week;
    displayInWeekCalender(transitonTimestamp);
}

// Wechsel zu folgender Woche
function nextWeek() {
    transitonTimestamp = transitonTimestamp + Week;
    displayInWeekCalender(transitonTimestamp);
}

// Wechsel zu vorherigem Tag
function prevDay() {
    transitonTimestamp = transitonTimestamp - Day;
    displayInDayCalender(transitonTimestamp);
}

// Wechsel zu folgendem Woche
function nextday() {
    transitonTimestamp = transitonTimestamp + Day;
    displayInDayCalender(transitonTimestamp);
}

// Laden des Monatskalenders
function loadMonth() {
// Erstellen einer HTML Grundform für Monatskalender
    $(".dayDisplayWrapper").each(function (i, element) {
        for (var j = 0, max = 6; j < max; j++) {
            var div = document.createElement("div");
            div.setAttribute("class", "dayDisplay");
            var h3 = document.createElement("h3");
            h3.innerHTML = "Platzhalter";
            div.appendChild(h3);
            $(element).append(div);
        }
    });
// Einfügen der Termine in den Kalender
    displayInMonthCalender(FirstOfCurrentMonth);
}

// Laden des Wochenkalenders
function loadWeek() {
// Einfügen der Termine in den Kalender
    displayInWeekCalender(BaseTimestamp);
}

// Laden des Tageskalenders
function dayLoad() {
// Einfügen der Termine in den Kalender
    displayInDayCalender(BaseTimestamp);
}

// Anzeige der zum Tag gehörenden Termine im Tageskalender
function displayAppointmentDay(appointment) {
    var start = new Date(parseInt(appointment.beginTimestamp));
    var divContainer = document.createElement("div");
    var divUpperWrapper = document.createElement("div");
    var divLowerWrapper = document.createElement("div");
    var h3 = document.createElement("h3");
    var p1 = document.createElement("p");
    var p2 = document.createElement("p");

    divContainer.setAttribute("class", "appointmentDisplay");
    divContainer.setAttribute("data-id", appointment.id);
    divUpperWrapper.setAttribute("class", "appointmentUpperWrapper");
    divLowerWrapper.setAttribute("class", "appointmentLowerWrapper");

    h3.setAttribute("class", "appointmentDisplayEvent");
    h3.innerHTML = appointment.event;
    divUpperWrapper.appendChild(h3);
    p1.setAttribute("class", "appointmentDisplayDuration");
    p1.innerHTML = "Dauer: " + appointment.duration;
    divUpperWrapper.appendChild(p1);

    p2.setAttribute("class", "appointmentDisplayNote");
    p2.innerHTML = appointment.note;
    divLowerWrapper.appendChild(p2);

    divContainer.appendChild(divUpperWrapper);
    divContainer.appendChild(divLowerWrapper);

    if (appointment.duration < 90) {
        $("[data-hour=" + start.getUTCHours() + "]").css({
            "height": "60px"
        });
        var height = (appointment.duration - 60) / 2;
        var margin = (start.getUTCMinutes() / 2);
        $(divContainer).css({
            "height": (60 + height),
            "margin-top": (margin)
        });
    } else {
        $(divContainer).css({
            "height": (appointment.duration / 2) - 1,
            "margin-top": (start.getUTCMinutes() / 2)
        });
    }
    $("[data-hour=" + start.getUTCHours() + "]").append(divContainer);
}

// Anzeige der zur Woche gehörenden Termine im Wochenkalender
function displayAppointmentWeek(appointment, dayTimestamp) {
    var start = new Date(parseInt(appointment.beginTimestamp));
    var divContainer = document.createElement("div");
    var h3 = document.createElement("h3");
    var p = document.createElement("p");

    divContainer.setAttribute("class", "appointmentDisplay");
    divContainer.setAttribute("data-id", appointment.id);

    h3.setAttribute("class", "appointmentDisplayEvent");
    h3.innerHTML = appointment.event;
    divContainer.appendChild(h3);

    p.setAttribute("class", "appointmentDisplayDuration");
    p.innerHTML = "Dauer: " + appointment.duration;
    divContainer.appendChild(p);

    $(divContainer).css({
        "height": (appointment.duration / 2) - 1,
        "margin-top": (start.getUTCMinutes() / 2)
    });

    $("[data-timestamp=" + dayTimestamp + "] [data-hour=" + start.getUTCHours() + "]").append(divContainer);
}

// Anzeige der zum Monat gehörenden Termine im Monatskalender
function displayAppointmentMonth(appointment, dayTimestamp, counter) {
    var start = new Date(parseInt(appointment.beginTimestamp));
    if ($(".dayDisplay[data-timestamp=" + dayTimestamp + "] .appointmentDisplay").length === 0) {
        var divContainer = document.createElement("div");
        var divContentDisplay = document.createElement("div");
        var h3 = document.createElement("h3");
        var p = document.createElement("p");
        divContainer.setAttribute("class", "appointmentDisplay");
        h3.setAttribute("class", "appointmentDisplayEvent");
        h3.innerHTML = counter + " Termin";
        divContainer.appendChild(h3);
        p.setAttribute("data-id", appointment.id);
        p.innerHTML = leadingZeros(start.getUTCHours()) + ":" + leadingZeros(start.getUTCMinutes());
        divContentDisplay.setAttribute("class", "appointment");
        divContentDisplay.appendChild(p);
        divContainer.appendChild(divContentDisplay);
        $(".dayDisplay[data-timestamp=" + dayTimestamp + "]").append(divContainer);
    }
    if (counter > 1) {
        $(".dayDisplay[data-timestamp=" + dayTimestamp + "] .appointmentDisplay h3").text(counter + " Termine");
        var p = document.createElement("p");
        p.setAttribute("data-id", appointment.id);
        p.innerHTML = leadingZeros(start.getUTCHours()) + ":" + leadingZeros(start.getUTCMinutes());
        $(".dayDisplay[data-timestamp=" + dayTimestamp + "] .appointmentDisplay .appointment").append(p);
    }
}

// Kontrolle ob zum Zeitpunkt schon ein Termin besteht oder der Anfangs- und Endzeitpunkt 
// gleich sind 
function checkAppointmentCrossing(begin, end) {
    if (begin === end || end < begin) {
        alert("Begin - und Endzeitpunkt sind gleich oder der Endzeitpunkt liegt vor dem Begin!");
        return false;
    }
    if (begin < Date.now()) {
        alert("Dieser Zeitpunkt ist schon vergangen!");
        return false;
    }
    for (var i = 0; i < appointments.length && appointments.length > 1; i++) {
        if (appointments[i].id !== appointmentID) {
            var xStart = parseInt(appointments[i].beginTimestamp);
            var xEnd = parseInt(appointments[i].endTimestamp);
            if ((begin >= xStart && begin < xEnd) || (end > xStart && end <= xEnd)) {
                alert("Es gibt schon einen Termin für diesen Zeitraum!");
                return false;
            }
        }
    }
    return true;
}

// Isoliert einen Termin aus der Liste appointments durch angabe der ID 
function getAppointmentFromList(id) {
    var resultAppointment;
    for (var i = 0; i < appointments.length; i++) {
        if (id === appointments[i].id) {
            resultAppointment = appointments[i];
        }
    }
    return resultAppointment;
}

// Setzt sesssessionStorage.appointmentCheck = true 
function setAppointmentCheck() { // WIP
    if (sessionStorage.appointmentCheck === undefined) {
        sessionStorage.setItem("appointmentCheck", "true");
    }
    sessionStorage.appointmentCheck = "true";
}

// Schreibt die Daten des zu bearbeitenden Termins in das Formular zum Berabeiten
function setUpdateAppointment(id) {
    for (var i = 0, max = appointments.length; i < max; i++) {
        if (appointments[i].id === id) {
            var temp;
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(1)").find("input").val(appointments[i].event);
            var begin = new Date(parseInt(appointments[i].beginTimestamp));
            var end = new Date(parseInt(appointments[i].endTimestamp));
            temp = leadingZeros(parseInt(begin.getUTCHours()));
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(2)").find("select:nth-of-type(1)").val(temp);
            temp = leadingZeros(parseInt(end.getUTCHours()));
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(3)").find("select:nth-of-type(1)").val(temp);
            temp = leadingZeros(parseInt(begin.getUTCMinutes()));
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(2)").find("select:nth-of-type(2)").val(temp);
            temp = leadingZeros(parseInt(end.getUTCMinutes()));
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(3)").find("select:nth-of-type(2)").val(temp);
            $(".editAppointmentForm .appointmentFormInputWrapper:nth-of-type(4)").find("textarea").val(appointments[i].note);
        }
    }
}

$().ready(function () {
    // laden der Termine vom Server
    $.post("../../getAppointmentServlet", function (responseText) {
        appointments = responseText;
        if (sessionStorage.page === "daycalender" || sessionStorage.page === undefined) {
            var div = document.createElement("div");
            div.setAttribute("class", "calenderDayWrapper");
            $(".contentWrapper").prepend(div);
            // Laden des Tageskalender-Templates 
            $(".calenderDayWrapper").load("../templates/calendarDayWrapper.tpl.html", dayLoad);
            $("#appointmentWeekDateSelect").parent().hide();
            // Event zum Anzaigen des vorherigen Tages
            $(".addAppointmentPrevButton").click(function () {
                prevDay();
            });
            // Event zum Anzeigen des folgenden Tages
            $(".addAppointmentNextButton").click(function () {
                nextday();
            });
            // Event für die Anzeige des Formulars zum hinzufügen eines Termins
            $(".calenderDayWrapper").click(function (event) {
                event.stopPropagation();
                appointmentTimestamp = parseInt($(".calenderDayWrapper h2[data-timestamp]").attr("data-timestamp"));
                $(".addAppointmentFormWrapper").show();
            });
        } else if (sessionStorage.page === "weekcalender") {
            var div = document.createElement("div");
            div.setAttribute("class", "calenderWeekWrapper");
            $(".contentWrapper").prepend(div);
            // Laden des Wochenkalender-Templates 
            $(".calenderWeekWrapper").load("../templates/calendarWeekWrapper.tpl.html", loadWeek);
            // Event zum Anzaigen der vorherigen Woche
            $(".addAppointmentPrevButton").click(function () {
                prevWeek();
            });
            // Event zum Anzeigen der folgenden Woche
            $(".addAppointmentNextButton").click(function () {
                nextWeek();
            });
        } else {
            var div = document.createElement("div");
            div.setAttribute("class", "calenderMonthWrapper");
            $(".contentWrapper").prepend(div);
            // Laden des Monatskalender-Templates 
            $(".calenderMonthWrapper").load("../templates/calendarMonthWrapper.tpl.html", loadMonth);
            // Event zum Anzaigen des vorherigen Monats
            $(".addAppointmentPrevButton").click(function () {
                prevMonth();
            });
            // Event zum Anzeigen des folgenden Monats
            $(".addAppointmentNextButton").click(function () {
                nextMonth();
            });
        }
    });

    // Setzt sesssessionStorage.appointmentCheck = false 
    if (sessionStorage.appointmentCheck === "true") {
        // AJAX Request zum Übertragen der Termine in die Datenbank
        $.post("../../appointmentToDBServlet");
        sessionStorage.appointmentCheck = "false";
    }

    // Event zum Verstecken aller Formulare
    $(".backButtonAppointment").click(function () {
        $(".addAppointmentFormWrapper").hide();
        $(".editAppointmentFormWrapper").hide();
    });

    // Nach Klickevent Setzen der sessionStorage.page
    $("aside.mainNav #dayCalenderLink").click(function () {
        sessionStorage.setItem("page", "daycalender");
    });
    // Nach Klickevent Setzen der sessionStorage.page
    $("aside.mainNav #weekCalenderLink").click(function () {
        sessionStorage.setItem("page", "weekcalender");
    });
    // Nach Klickevent Setzen der sessionStorage.page
    $("aside.mainNav #monthCalenderLink").click(function () {
        sessionStorage.setItem("page", "monthcalender");
    });

    // Nach Klickevent Setzen der updateOrDelete 
    // wenn ein Termin bearbeitet wird = true
    $("input[id*='editAppointmentButton']").click(function () {
        updateOrDelete = true;
    });

    // Nach Klickevent Setzen der updateOrDelete
    // wenn ein Termin gelöscht wird = false
    $("input[id*='delAppointmentButton']").click(function () {
        updateOrDelete = false;
    });

    // Anzeige und Setzen von Zeichenlimit
    $("textarea[id*='addNoteTextarea']").on("keyup", function () {
        var temp = this.value;
        var length = temp.length;
        var limit = 150 - length;
        $(".charLimitDisplay").text("Zeichenlimit " + limit);
        if (limit <= 0) {
            alert("Zeichenlimit erreicht!");
            this.value = temp.substring(0, 149);
        }
    });

    // Anzeige und Setzen von Zeichenlimit
    $("textarea[id*='editNoteTextarea']").on("keyup", function () {
        var temp = this.value;
        var length = temp.length;
        var limit = 150 - length;
        $(".charLimitDisplay").text("Zeichenlimit " + limit);
        if (limit <= 0) {
            alert("Zeichenlimit erreicht!");
            this.value = temp.substring(0, 149);
        }
    });

    // Vorbereitung der Daten vor dem Submit eines neuen Termins
    $("#addAppointmentFormId").submit(function () {
        var begin = ($("#addBeginTimeHourSelect").val() * Hour) + ($("#addBeginTimeMinuteSelect").val() * Minute) + appointmentTimestamp;
        var end = ($("#addEndTimeHourSelect").val() * Hour) + ($("#addEndTimeMinuteSelect").val() * Minute) + appointmentTimestamp;
        var duration = (end - begin) / 60000;
        $("input[id*='addAppointmentInputBegin']").val(begin);
        $("input[id*='addAppointmentInputEnd']").val(end);
        $("input[id*='addAppointmentInputDuration']").val(duration);
        setAppointmentCheck();
        appointmentID = undefined;
        return checkAppointmentCrossing(begin, end);
    });

    // Vorbereitung der Daten vor dem Submit eines atualisierten Termins
    $("#editAppointmentFormId").submit(function () {
        $("input[id*='editAppointmentInputID']").val(appointmentID);
        if (updateOrDelete) {
            var begin = ($("#editBeginTimeHourSelect").val() * Hour) + ($("#editBeginTimeMinuteSelect").val() * Minute) + appointmentTimestamp;
            var end = ($("#editEndTimeHourSelect").val() * Hour) + ($("#editEndTimeMinuteSelect").val() * Minute) + appointmentTimestamp;
            var duration = (end - begin) / 60000;
            $("input[id*='editAppointmentInputBegin']").val(begin);
            $("input[id*='editAppointmentInputEnd']").val(end);
            $("input[id*='editAppointmentInputDuration']").val(duration);
            return checkAppointmentCrossing(begin, end);
        } else {
            return confirm("Möchten Sie diesen Eintrag Löschen?");
        }
    });
});

