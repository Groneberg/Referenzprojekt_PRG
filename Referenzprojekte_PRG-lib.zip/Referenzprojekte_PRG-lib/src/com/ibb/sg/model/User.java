/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.model;

import java.io.Serializable;

/**
 *
 * @author Stefan Groneberg
 */
public class User implements Serializable{
    private String eMail;
    private String pw;

    public User() {
    }

    public User(String eMail, String pw) {
        this.eMail = eMail;
        this.pw = pw;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }
}
