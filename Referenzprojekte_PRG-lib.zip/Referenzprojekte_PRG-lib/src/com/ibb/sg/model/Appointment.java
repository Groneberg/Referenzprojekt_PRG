/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.sg.model;

import java.io.Serializable;

/**
 *
 * @author Stefan Groneberg
 */
public class Appointment implements Serializable {

    private String id;
    private String event;
    private String note;
//    private String date;
    private String beginTimestamp;
    private String endTimestamp;
    private int duration;

    public Appointment() {
    }

    public Appointment(String id, String event, String note, String beginTimestamp, String endTimestamp, int duration) {
        this.id = id;
        this.event = event;
        this.note = note;
        this.beginTimestamp = beginTimestamp;
        this.endTimestamp = endTimestamp;
        this.duration = duration;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getBeginTimestamp() {
        return beginTimestamp;
    }

    public void setBeginTimestamp(String beginTimestamp) {
        this.beginTimestamp = beginTimestamp;
    }

    public String getEndTimestamp() {
        return endTimestamp;
    }

//    public String getDate() {
//        return date;
//    }
//
//    public void setDate(String date) {
//        this.date = date;
//    }
    public void setEndTimestamp(String endTimestamp) {
        this.endTimestamp = endTimestamp;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    public void setStartTimestamp() {
        // code
    }
    
    public void setEndTimestamp() {
        // code
    }
}
