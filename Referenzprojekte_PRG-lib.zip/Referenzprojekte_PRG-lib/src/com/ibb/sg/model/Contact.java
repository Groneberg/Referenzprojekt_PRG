package com.ibb.sg.model;

import java.io.Serializable;

/**
 *
 * @author Stefan Groneberg
 */
public class Contact implements Serializable{
    private String id;
    private String firstName;
    private String lastName;
    private String phone;
    private String eMail;
    private String address;
    private String location;
    private String zip;
    private String label;
    private String title;

    public Contact() {
    }

    public Contact(String id, String firstName, String lastName, String phone, String eMail, String address, String location, String zip, String label, String title) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.eMail = eMail;
        this.address = address;
        this.location = location;
        this.zip = zip;
        this.label = label;
        this.title = title;
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    @Override
    public String toString() {
        return 
                this.firstName + " " +
                this.lastName + " " +
                this.title + " " +
                this.address + " " + 
                this.eMail + " " + 
                this.phone + " " + 
                this.zip + " " + 
                this.location + " " + 
                this.label;
    }
}
